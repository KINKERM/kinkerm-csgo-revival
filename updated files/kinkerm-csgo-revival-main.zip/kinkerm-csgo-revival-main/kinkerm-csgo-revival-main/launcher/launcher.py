from __future__ import annotations

import os
import subprocess
import sys
import time
import urllib.error
import urllib.request

REQUIRED = ("server_url", "steam_id", "csgo_dir")
TRUE_VALUES = {"1", "true", "yes", "on"}


def load_config(path: str) -> dict:
    config = {
        "server_url": "", "steam_id": "", "csgo_dir": "",
        "game_exe": "", "game_args": "", "launch_game": "1",
        "sync_token": "",
    }
    if not os.path.exists(path):
        print(f"[launcher] config file not found: {path}")
        print("[launcher] copy launcher.example.cfg to launcher.cfg and edit it.")
        sys.exit(1)
    with open(path, "r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line or line[0] in "#;" or "=" not in line:
                continue
            key, _, value = line.partition("=")
            key, value = key.strip(), value.strip()
            if key in config:
                config[key] = value
    for req in REQUIRED:
        if not config[req]:
            print(f"[launcher] '{req}' is required in {path}")
            sys.exit(1)
    if not config["game_exe"]:
        if sys.platform.startswith("win"):
            config["game_exe"] = "csgo.exe"
        elif sys.platform == "darwin":
            config["game_exe"] = "csgo_osx64"
        else:
            config["game_exe"] = "csgo_linux64"
    if not config["game_args"]:
        config["game_args"] = "-steam -game csgo -novid"
    return config


def inventory_url(config: dict) -> str:
    return config["server_url"].rstrip("/") + "/inventory/" + config["steam_id"]


def inventory_path(config: dict) -> str:
    return os.path.join(config["csgo_dir"], "csgo_gc", "inventory.txt")


def fetch_file(url: str, desc: str) -> bytes:
    print(f"[launcher] fetching {desc}")
    try:
        with urllib.request.urlopen(url, timeout=15) as resp:
            return resp.read()
    except urllib.error.URLError as exc:
        print(f"[launcher] failed to fetch {desc}: {exc}")
        sys.exit(2)


def write_file(path: str, data: bytes) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"[launcher] wrote {len(data)} bytes -> {path}")


def fetch_inventory(config: dict) -> None:
    body = fetch_file(inventory_url(config), "inventory")
    write_file(inventory_path(config), body)


def upload_file(url: str, path: str, desc: str, token: str) -> None:
    if not os.path.exists(path):
        print(f"[launcher] no {desc} to upload at {path}")
        return
    with open(path, "rb") as fh:
        body = fh.read()
    req = urllib.request.Request(
        url, data=body, method="POST",
        headers={"X-Sync-Token": token,
                 "Content-Type": "text/plain; charset=utf-8"},
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            print(f"[launcher] uploaded {desc} ({resp.status}) - saved.")
    except urllib.error.HTTPError as exc:
        print(f"[launcher] upload {desc} failed: HTTP {exc.code}")
    except urllib.error.URLError as exc:
        print(f"[launcher] upload {desc} failed: {exc}")


def upload_inventory(config: dict) -> None:
    if not config["sync_token"]:
        return
    upload_file(inventory_url(config), inventory_path(config),
                "inventory", config["sync_token"])


def launch_and_wait(config: dict) -> None:
    exe = os.path.join(config["csgo_dir"], config["game_exe"])
    if not os.path.exists(exe):
        print(f"[launcher] game executable not found: {exe}")
        sys.exit(3)

    args = [exe] + config["game_args"].split()
    print(f"[launcher] launching {exe} ...")
    try:
        proc = subprocess.Popen(args, cwd=config["csgo_dir"])
    except OSError as exc:
        print(f"[launcher] failed to launch game: {exc}")
        sys.exit(4)

    if not config["sync_token"]:
        print("[launcher] launched. (No sync_token set, changes won't persist.)")
        return

    print("[launcher] launched. Waiting for you to close the game to save changes...")
    proc.wait()
    time.sleep(2)
    print("[launcher] game closed - saving your data back to the server.")
    upload_inventory(config)


def main() -> None:
    here = os.path.dirname(os.path.abspath(__file__))

    args = sys.argv[1:]
    upload_only = "--upload" in args
    cfg_args = [a for a in args if not a.startswith("--")]
    cfg_path = cfg_args[0] if cfg_args else os.path.join(here, "launcher.cfg")

    config = load_config(cfg_path)

    if upload_only:
        upload_inventory(config)
        return

    fetch_inventory(config)

    if config["launch_game"].lower() not in TRUE_VALUES:
        print("[launcher] launch_game is off; files synced, not launching.")
        return

    launch_and_wait(config)


if __name__ == "__main__":
    main()