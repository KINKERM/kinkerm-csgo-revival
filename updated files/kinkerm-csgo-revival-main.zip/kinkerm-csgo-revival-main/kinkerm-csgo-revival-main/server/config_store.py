"""Per-player config.txt storage and management.

csgo_gc reads config.txt as flat top-level KeyValues. Keys like vac_banned,
player_level, cmd_friendly, etc. are TOP-LEVEL. Only ranks and rarity_weights
are nested blocks. We must preserve this exact structure or csgo_gc ignores it.
"""

from __future__ import annotations

import json
import os
import threading
from typing import Any


# Default config matching csgo_gc's expected format EXACTLY.
# Everything here is a string because KV files are stringly-typed.
DEFAULT_CONFIG: dict[str, Any] = {
    "ranks": {
        "competitive_rank": "0",
        "competitive_wins": "0",
        "wingman_rank": "0",
        "wingman_wins": "0",
        "dangerzone_rank": "0",
        "dangerzone_wins": "0",
    },
    "vac_banned": "0",
    "cmd_friendly": "666",
    "cmd_teaching": "777",
    "cmd_leader": "888",
    "player_level": "1",
    "player_cur_xp": "0",
    "destroy_used_items": "1",
    "gold_tradeup_crate": "0",
    "gold_only_crate": "0",
    "rarity_weights": {
        "1": "10000000",
        "2": "2000000",
        "3": "400000",
        "4": "160000",
        "5": "32000",
        "6": "6400",
        "99": "2560",
    },
    "appid_override": "4465480",
    "show_csgo_gc_servers_only": "1",
    "log_output": "1",
}


def _deep_merge(base: dict, override: dict) -> dict:
    """Recursively merge override into base, preserving unknown keys."""
    result = dict(base)
    for key, val in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(val, dict):
            result[key] = _deep_merge(result[key], val)
        else:
            result[key] = val
    return result


class ConfigStore:
    def __init__(self, configs_path: str):
        self._path = configs_path
        self._lock = threading.RLock()
        self._configs: dict[str, dict[str, Any]] = {}
        self._load()

    def _load(self) -> None:
        if os.path.exists(self._path):
            with open(self._path, "r", encoding="utf-8") as fh:
                self._configs = json.load(fh)
        else:
            self._configs = {}

    def _save(self) -> None:
        os.makedirs(os.path.dirname(os.path.abspath(self._path)), exist_ok=True)
        tmp = self._path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(self._configs, fh, indent=2)
        os.replace(tmp, self._path)

    def _ensure(self, steamid: str) -> dict[str, Any]:
        if steamid not in self._configs:
            self._configs[steamid] = json.loads(json.dumps(DEFAULT_CONFIG))
        return self._configs[steamid]

    # ---- queries -----------------------------------------------------------
    def get_config(self, steamid: str) -> dict[str, Any]:
        with self._lock:
            return json.loads(json.dumps(self._ensure(steamid)))

    def get_config_txt(self, steamid: str) -> str:
        """Return the csgo_gc-compatible config.txt text."""
        with self._lock:
            cfg = self._ensure(steamid)
            import kvwriter
            return kvwriter.dumps_top(cfg)

    def list_players(self) -> list[str]:
        with self._lock:
            return sorted(self._configs.keys())

    # ---- mutations ---------------------------------------------------------
    def update_config(self, steamid: str, updates: dict[str, Any]) -> dict[str, Any]:
        """Apply partial updates (flattened or nested) to a player\'s config."""
        with self._lock:
            cfg = self._ensure(steamid)
            merged = _deep_merge(cfg, updates)
            self._configs[steamid] = merged
            self._save()
            return json.loads(json.dumps(merged))

    def set_vac_banned(self, steamid: str, banned: bool, ban_end_time: int = 0) -> dict[str, Any]:
        """Toggle VAC ban status. vac_banned is TOP-LEVEL in csgo_gc."""
        with self._lock:
            cfg = self._ensure(steamid)
            cfg["vac_banned"] = "1" if banned else "0"
            # ban_end_time is also stored top-level for our own bookkeeping
            cfg["ban_end_time"] = str(ban_end_time)
            self._save()
            return {"vac_banned": cfg["vac_banned"], "ban_end_time": cfg["ban_end_time"]}

    def reset_config(self, steamid: str) -> None:
        with self._lock:
            self._configs[steamid] = json.loads(json.dumps(DEFAULT_CONFIG))
            self._save()

    def delete_config(self, steamid: str) -> None:
        with self._lock:
            if steamid in self._configs:
                del self._configs[steamid]
                self._save()
