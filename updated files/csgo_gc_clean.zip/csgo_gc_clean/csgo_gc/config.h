#pragma once

#include <unordered_map>

#include "gc_const_csgo.h"
#include "item_schema.h" // rarity constants

struct RarityWeight
{
    uint32_t rarity;
    float weight;
};

// for Platform::Print calls
enum LogOutput
{
    LogOutputNone, // don't output anything
    LogOutputConsole, // game console
    LogOutputFile // game console and gc_log.txt
};

class GCConfig
{
public:
    GCConfig();

    // options used by platform layer (bruh)
    LogOutput GetLogOutput() const { return m_logOutput; }

    // options used by steam hook
    uint32_t AppIdOverride() const { return m_appIdOverride; }
    bool ShowCsgoGCServersOnly() const { return m_showCsgoGCServersOnly; }

    RankId CompetitiveRank() const { return m_competitiveRank; }
    int CompetitiveWins() const { return m_competitiveWins; }
    RankId WingmanRank() const { return m_wingmanRank; }
    int WingmanWins() const { return m_wingmanWins; }
    DangerZoneRankId DangerZoneRank() const { return m_dangerZoneRank; }
    int DangerZoneWins() const { return m_dangerZoneWins; }

    bool DestroyUsedItems() const { return m_destroyUsedItems; }

    // trade-up contracts (revival addition): opening this crate def index runs
    // the 5-Covert -> gold recipe instead of a normal case roll. 0 = disabled.
    uint32_t GoldTradeUpCrate() const { return m_goldTradeUpCrate; }

    // "gold only" case (revival addition): opening this crate def always rolls a
    // random gold (knife/glove) from any collection - no Coverts consumed, just
    // the case. Admin-grant it like any case. 0 = disabled.
    uint32_t GoldOnlyCrate() const { return m_goldOnlyCrate; }

    // "gold only, restricted" case (revival addition): like GoldOnlyCrate, but
    // the gold is drawn only from this specific crate's own loot list (e.g. a
    // themed sub-pool like "Horizon knives in Gamma finishes") instead of every
    // collection in the game. List multiple crate defs under
    // gold_only_crates_restricted in config.txt.
    bool IsGoldOnlyCrateRestricted(uint32_t defIndex) const;

    // operation store (revival addition): def index of the item that holds the
    // player's star balance (an "operation_coin" prefab item, upgrade_level
    // attribute = star count). 0 = feature disabled.
    uint32_t StarCoinDefIndex() const { return m_starCoinDefIndex; }

    // operation store (revival addition): star cost to redeem defIndex (an
    // existing case OR a custom collection/sticker capsule/agent crate - it
    // only needs a revolving_loot_lists entry, same as any case). Returns 0 if
    // defIndex isn't redeemable for stars.
    uint32_t GetStarCost(uint32_t defIndex) const;

    // operation store (revival addition): star cost to DIRECTLY purchase
    // defIndex outright (e.g. buy an actual unopened case - no roll, no key
    // consumed, you get the exact item and open it normally later). Separate
    // from GetStarCost/redeeming: same currency, different admin-configured
    // list, so you can put the identical def in either table depending on
    // whether you want it to redeem-and-roll or just hand it over as-is.
    // Returns 0 if defIndex isn't set up for direct purchase.
    uint32_t GetDirectPurchaseStarCost(uint32_t defIndex) const;

    bool VacBanned() const { return m_vacBanned; }
    int CommendedFriendly() const { return m_commendedFriendly; }
    int CommendedTeaching() const { return m_commendedTeaching; }
    int CommendedLeader() const { return m_commendedLeader; }
    int Level() const { return m_level; }
    int Xp() const { return m_xp; }

    float GetRarityWeight(uint32_t rarity) const;

private:
    LogOutput m_logOutput{ LogOutputConsole };

    // actually default to 4465480 instead of 730, people are going to use old configs
    // and then wonder why the game doesn't work and open an issue on github otherwise
    uint32_t m_appIdOverride{ 4465480 };
    bool m_showCsgoGCServersOnly{ true };

    RankId m_competitiveRank{ RankNone };
    int m_competitiveWins{ 0 };
    RankId m_wingmanRank{ RankNone };
    int m_wingmanWins{ 0 };
    DangerZoneRankId m_dangerZoneRank{ DangerZoneRankNone };
    int m_dangerZoneWins{ 0 };

    bool m_destroyUsedItems{ true };

    // trade-up contracts (revival addition): crate def that triggers 5 Covert -> gold
    uint32_t m_goldTradeUpCrate{ 0 };

    // "gold only" case (revival addition): crate def that always rolls a gold
    uint32_t m_goldOnlyCrate{ 0 };

    // "gold only, restricted" case (revival addition): crate defs that always
    // roll a gold from just their own loot list
    std::vector<uint32_t> m_goldOnlyCratesRestricted;

    // operation store (revival addition)
    uint32_t m_starCoinDefIndex{ 0 };
    std::unordered_map<uint32_t, uint32_t> m_redeemableForStars;
    std::unordered_map<uint32_t, uint32_t> m_directPurchaseForStars;

    bool m_vacBanned{ false };
    int m_commendedFriendly{ 0 };
    int m_commendedTeaching{ 0 };
    int m_commendedLeader{ 0 };
    int m_level{ 0 };
    int m_xp{ 0 };

    // default to valve weights
    std::vector<RarityWeight> m_rarityWeights{
        { ItemSchema::RarityCommon, 10000000 },
        { ItemSchema::RarityUncommon, 2000000 },
        { ItemSchema::RarityRare, 400000 },
        { ItemSchema::RarityMythical, 80000 },
        { ItemSchema::RarityLegendary, 16000 },
        { ItemSchema::RarityAncient, 3200 },
        { ItemSchema::RarityUnusual, 1280 },
    };
};

const GCConfig &GetConfig();
