#include "stdafx.h"
#include "config.h"
#include "keyvalue.h"
#include "random.h"

constexpr const char *ConfigFilePath = "csgo_gc/config.txt";

const GCConfig &GetConfig()
{
    static GCConfig instance;
    return instance;
}

GCConfig::GCConfig()
{
    KeyValue config{ "config" };

    if (!config.ParseFromFile(ConfigFilePath))
    {
        return;
    }

    m_logOutput = config.GetNumber("log_output", m_logOutput);

    m_appIdOverride = config.GetNumber("appid_override", m_appIdOverride);
    m_showCsgoGCServersOnly = config.GetNumber("show_csgo_gc_servers_only", m_showCsgoGCServersOnly);

    const KeyValue *ranks = config.GetSubkey("ranks");
    if (ranks)
    {
        m_competitiveRank = ranks->GetNumber("competitive_rank", m_competitiveRank);
        m_competitiveWins = ranks->GetNumber("competitive_wins", m_competitiveWins);

        m_wingmanRank = ranks->GetNumber("wingman_rank", m_wingmanRank);
        m_wingmanWins = ranks->GetNumber("wingman_wins", m_wingmanWins);

        m_dangerZoneRank = ranks->GetNumber("dangerzone_rank", m_dangerZoneRank);
        m_dangerZoneWins = ranks->GetNumber("dangerzone_wins", m_dangerZoneWins);
    }

    m_destroyUsedItems = config.GetNumber("destroy_used_items", m_destroyUsedItems);

    // trade-up contracts (revival addition): the crate that performs 5 Covert -> gold
    m_goldTradeUpCrate = config.GetNumber("gold_tradeup_crate", m_goldTradeUpCrate);

    // "gold only" case (revival addition): the crate that always rolls a gold
    m_goldOnlyCrate = config.GetNumber("gold_only_crate", m_goldOnlyCrate);

    // "gold only, restricted" case (revival addition): crates that roll a gold
    // from just their own loot list. e.g.:
    //   "gold_only_crates_restricted"
    //   {
    //       "0"    "9602"
    //   }
    const KeyValue *goldOnlyRestricted = config.GetSubkey("gold_only_crates_restricted");
    if (goldOnlyRestricted)
    {
        m_goldOnlyCratesRestricted.clear();
        m_goldOnlyCratesRestricted.reserve(goldOnlyRestricted->SubkeyCount());

        for (const KeyValue &subkey : *goldOnlyRestricted)
        {
            m_goldOnlyCratesRestricted.push_back(FromString<uint32_t>(subkey.String()));
        }
    }

    // operation store (revival addition)
    m_starCoinDefIndex = config.GetNumber("star_coin_def_index", m_starCoinDefIndex);

    // "redeemable_for_stars"
    // {
    //     "9600"    "10"   // def index -> star cost. works for any existing
    //     "4061"    "5"    // case (real or custom) or a self-opening
    // }                    // collection/sticker/agent crate - it only needs a
    //                      // revolving_loot_lists entry, same as any case.
    const KeyValue *redeemable = config.GetSubkey("redeemable_for_stars");
    if (redeemable)
    {
        m_redeemableForStars.clear();

        for (const KeyValue &subkey : *redeemable)
        {
            uint32_t defIndex = FromString<uint32_t>(subkey.Name());
            uint32_t cost = FromString<uint32_t>(subkey.String());
            m_redeemableForStars[defIndex] = cost;
        }
    }

    // "direct_purchase_for_stars"
    // {
    //     "4061"    "8"   // buy this exact case outright for 8 stars - no
    // }                   // roll, no key, just the item (open it normally
    //                      // later). Put a def here INSTEAD of in
    //                      // redeemable_for_stars if you don't want it to
    //                      // auto-open.
    const KeyValue *directPurchase = config.GetSubkey("direct_purchase_for_stars");
    if (directPurchase)
    {
        m_directPurchaseForStars.clear();

        for (const KeyValue &subkey : *directPurchase)
        {
            uint32_t defIndex = FromString<uint32_t>(subkey.Name());
            uint32_t cost = FromString<uint32_t>(subkey.String());
            m_directPurchaseForStars[defIndex] = cost;
        }
    }

    const KeyValue *rarityWeights = config.GetSubkey("rarity_weights");
    if (rarityWeights)
    {
        m_rarityWeights.clear();
        m_rarityWeights.reserve(rarityWeights->SubkeyCount());

        for (const KeyValue &subkey : *rarityWeights)
        {
            RarityWeight weight;
            weight.rarity = FromString<uint32_t>(subkey.Name());
            weight.weight = FromString<float>(subkey.String());
            m_rarityWeights.push_back(weight);
        }
    }

    m_vacBanned = config.GetNumber("vac_banned", m_vacBanned);
    m_commendedFriendly = config.GetNumber("cmd_friendly", m_commendedFriendly);
    m_commendedTeaching = config.GetNumber("cmd_teaching", m_commendedTeaching);
    m_commendedLeader = config.GetNumber("cmd_leader", m_commendedLeader);
    m_level = config.GetNumber("player_level", m_level);
    m_xp = config.GetNumber("player_cur_xp", m_xp);
}

bool GCConfig::IsGoldOnlyCrateRestricted(uint32_t defIndex) const
{
    for (uint32_t crate : m_goldOnlyCratesRestricted)
    {
        if (crate == defIndex)
        {
            return true;
        }
    }

    return false;
}

uint32_t GCConfig::GetStarCost(uint32_t defIndex) const
{
    auto it = m_redeemableForStars.find(defIndex);
    return it == m_redeemableForStars.end() ? 0 : it->second;
}

uint32_t GCConfig::GetDirectPurchaseStarCost(uint32_t defIndex) const
{
    auto it = m_directPurchaseForStars.find(defIndex);
    return it == m_directPurchaseForStars.end() ? 0 : it->second;
}

float GCConfig::GetRarityWeight(uint32_t rarity) const
{
    for (const RarityWeight &weight : m_rarityWeights)
    {
        if (weight.rarity == rarity)
        {
            return weight.weight;
        }
    }

    return 0;
}
