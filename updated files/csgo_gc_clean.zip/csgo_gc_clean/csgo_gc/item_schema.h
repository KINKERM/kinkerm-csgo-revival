#pragma once

#include "gc_const_csgo.h"

class KeyValue;
class Random;

enum class AttributeType
{
    Float,
    Uint32,
    String
};

class AttributeInfo
{
public:
    explicit AttributeInfo(const KeyValue &key);

    AttributeType m_type;
};

class ItemInfo
{
public:
    explicit ItemInfo(uint32_t defIndex);

    uint32_t m_defIndex;
    std::string m_name;
    uint32_t m_rarity;
    uint32_t m_quality;
    uint32_t m_level;
    uint32_t m_supplyCrateSeries; // cases only

    // kludge for coupons so we can buy stuff from the store
    bool m_isCoupon;
    std::string m_lootListName;
    bool m_willProduceStatTrak;
};

class PaintKitInfo
{
public:
    explicit PaintKitInfo(const KeyValue &key);

    uint32_t m_defIndex;
    uint32_t m_rarity;
    float m_minFloat;
    float m_maxFloat;
};

class StickerKitInfo
{
public:
    explicit StickerKitInfo(const KeyValue &key);

    uint32_t m_defIndex;
    uint32_t m_rarity;
};

class MusicDefinitionInfo
{
public:
    MusicDefinitionInfo(const KeyValue &key);

    uint32_t m_defIndex;
};

enum LootListItemType
{
    LootListItemNoAttribute,
    LootListItemPaintable,
    LootListItemSticker,
    LootListItemSpray,
    LootListItemPatch,
    LootListItemMusicKit,
};

struct LootListItem
{
    // for case opening: returns RarityUnusual for items of unusual quality
    uint32_t CaseRarity() const;

    const ItemInfo *itemInfo{};
    LootListItemType type{ LootListItemNoAttribute };

    // these could be sticked into a variant to save a grand total of few bytes
    const PaintKitInfo *paintKitInfo{};
    const StickerKitInfo *stickerKitInfo{};
    const MusicDefinitionInfo *musicDefinitionInfo{};

    // might differ from those specified in itemInfo
    // (based on paint kits, stattrak etc.)
    uint32_t rarity{};
    uint32_t quality{};
};

struct LootList
{
    // we either have items or sublists, never both
    std::vector<LootListItem> items;
    std::vector<const LootList *> subLists;
    bool willProduceStatTrak{};
    bool isUnusual{};
};

// trade-up contracts (revival addition)
// a single skin entry in a collection (item_set), with its computed grade
struct CollectionItem
{
    uint32_t itemDefIndex{};
    uint32_t paintKitDefIndex{};
    uint32_t rarity{};                       // PaintedItemRarity(item, paintkit)
    const ItemInfo *itemInfo{};
    const PaintKitInfo *paintKitInfo{};      // for the float (wear) range
};

// a collection / item_set (e.g. "set_community_2"). the trade-up output pool
// is the next-rarity skins from one of the input items' collections.
struct Collection
{
    std::string name;
    std::vector<CollectionItem> items;
};

class ItemSchema
{
public:
    ItemSchema();

    float AttributeFloat(const CSOEconItemAttribute *attribute) const;
    uint32_t AttributeUint32(const CSOEconItemAttribute *attribute) const;
    std::string AttributeString(const CSOEconItemAttribute *attribute) const;

    bool SetAttributeFloat(CSOEconItemAttribute *attribute, float value) const;
    bool SetAttributeUint32(CSOEconItemAttribute *attribute, uint32_t value) const;
    bool SetAttributeString(CSOEconItemAttribute *attribute, std::string_view value) const;

    // for case opening
    const LootList *GetCrateLootList(uint32_t crateDefIndex) const;

    // for case opening FIXME: do we want to keep this here???
    bool CreateItemFromLootListItem(Random &random,
        const LootListItem &lootListItem,
        bool statTrak,
        ItemOrigin origin,
        UnacknowledgedType unacknowledgedType,
        CSOEconItem &item) const;

    // item creation: id and account id not set, needs to be done by the caller
    bool CreateItem(uint32_t defIndex, ItemOrigin origin, UnacknowledgedType unacknowledgedType, CSOEconItem &econItem) const;

    // trade-up contracts (revival addition)
    // find the collection (and the matching entry) that contains a given skin
    // (weapon def index + paint kit def index). returns nullptr if the skin is
    // not part of any collection (i.e. not a valid trade-up input).
    const Collection *FindCollectionForItem(uint32_t itemDefIndex,
        uint32_t paintKitDefIndex,
        const CollectionItem **outItem) const;

    // trade-up contracts (revival addition) --- 5 Covert -> gold recipe
    // returns the unusual (knife/glove) loot list associated with the case that
    // a given Covert skin belongs to, or nullptr if none is known. The returned
    // LootList's items are the possible gold outputs.
    const LootList *FindUnusualPoolForItem(uint32_t itemDefIndex,
        uint32_t paintKitDefIndex) const;

    // "gold only" case (revival addition)
    // picks a uniform-random gold (knife/glove painted item) from EVERY unusual
    // loot list in the schema - i.e. a random gold from any collection. Returns
    // nullptr if no gold items exist. The returned LootListItem is owned by the
    // schema (points into m_lootLists) and must not be freed by the caller.
    const LootListItem *PickRandomGold(Random &random) const;

    // "gold only, restricted" case (revival addition)
    // like PickRandomGold, but scoped to a single crate's own loot list (found
    // the same way normal case opening does, via GetCrateLootList) instead of
    // every unusual list in the schema. Returns nullptr if the crate has no
    // loot list, or that loot list isn't flagged unusual (i.e. it only exists
    // in items_game.txt's client_loot_lists and not in
    // csgo_gc/unusual_loot_lists.txt). Ownership rules match PickRandomGold.
    const LootListItem *PickRandomGoldFromCrate(Random &random, uint32_t crateDefIndex) const;

public:
    // these could be parsed from the item schema but reduce code complexity by hardcoding them
    enum Rarity
    {
        RarityDefault = 0,
        RarityCommon = 1,
        RarityUncommon = 2,
        RarityRare = 3,
        RarityMythical = 4,
        RarityLegendary = 5,
        RarityAncient = 6,
        RarityImmortal = 7,

        RarityUnusual = 99
    };

    enum Quality
    {
        QualityNormal = 0,
        QualityGenuine = 1,
        QualityVintage = 2,
        QualityUnusual = 3,
        QualityUnique = 4,
        QualityCommunity = 5,
        QualityDeveloper = 6,
        QualitySelfmade = 7,
        QualityCustomized = 8,
        QualityStrange = 9,
        QualityCompleted = 10,
        QualityHaunted = 11,
        QualityTournament = 12
    };

    enum GraffitiTint
    {
        GraffitiTintMin = 1,
        GraffitiTintMax = 19
    };

    enum LoadoutSlot
    {
        LoadoutSlotGraffiti = 56
    };

    enum Item
    {
        ItemSpray = 1348,
        ItemSprayPaint = 1349,
        ItemPatch = 4609
    };

    enum Attribute
    {
        AttributeTexturePrefab = 6,
        AttributeTextureSeed = 7,
        AttributeTextureWear = 8,
        AttributeKillEater = 80,
        AttributeKillEaterScoreType = 81,

        // revival addition: def 268 = "upgrade level" (upgrade_level), a plain
        // integer attribute. Used as the star balance on the operation coin item.
        AttributeUpgradeLevel = 268,

        AttributeCustomName = 111,

        // ugh
        AttributeStickerId0 = 113,
        AttributeStickerWear0 = 114,
        AttributeStickerScale0 = 115,
        AttributeStickerRotation0 = 116,
        AttributeStickerId1 = 117,
        AttributeStickerWear1 = 118,
        AttributeStickerScale1 = 119,
        AttributeStickerRotation1 = 120,
        AttributeStickerId2 = 121,
        AttributeStickerWear2 = 122,
        AttributeStickerScale2 = 123,
        AttributeStickerRotation2 = 124,
        AttributeStickerId3 = 125,
        AttributeStickerWear3 = 126,
        AttributeStickerScale3 = 127,
        AttributeStickerRotation3 = 128,
        AttributeStickerId4 = 129,
        AttributeStickerWear4 = 130,
        AttributeStickerScale4 = 131,
        AttributeStickerRotation4 = 132,
        AttributeStickerId5 = 133,
        AttributeStickerWear5 = 134,
        AttributeStickerScale5 = 135,
        AttributeStickerRotation5 = 136,

        AttributeMusicId = 166,
        AttributeQuestId = 168,

        AttributeSpraysRemaining = 232,
        AttributeSprayTintId = 233,
    };

private:
    void ParseItems(const KeyValue *itemsKey, const KeyValue *prefabsKey);
    void ParseItemRecursive(ItemInfo &info, const KeyValue &itemKey, const KeyValue *prefabsKey);
    void ParseAttributes(const KeyValue *attributesKey);
    void ParseStickerKits(const KeyValue *stickerKitsKey);
    void ParsePaintKits(const KeyValue *paintKitsKey);
    void ParsePaintKitRarities(const KeyValue *raritiesKey);
    void ParseMusicDefinitions(const KeyValue *musicDefinitionsKey);
    void ParseLootLists(const KeyValue *lootListsKey, bool unusual);
    void ParseRevolvingLootLists(const KeyValue *revolvingLootListsKey);

    // trade-up contracts (revival addition)
    void ParseItemSets(const KeyValue *itemSetsKey);
    void BuildUnusualPools();

    bool ParseLootListItem(LootListItem &item, std::string_view name);

    // internal slop
    ItemInfo *ItemInfoByName(std::string_view name);
    StickerKitInfo *StickerKitInfoByName(std::string_view name);
    PaintKitInfo *PaintKitInfoByName(std::string_view name);
    MusicDefinitionInfo *MusicDefinitionInfoByName(std::string_view name);

    std::unordered_map<uint32_t, ItemInfo> m_itemInfo;
    std::unordered_map<uint32_t, AttributeInfo> m_attributeInfo;

    std::unordered_map<std::string, StickerKitInfo> m_stickerKitInfo;
    std::unordered_map<std::string, PaintKitInfo> m_paintKitInfo;
    std::unordered_map<std::string, MusicDefinitionInfo> m_musicDefinitionInfo;
    std::unordered_map<std::string, LootList> m_lootLists;

    std::unordered_map<uint32_t, const LootList &> m_revolvingLootLists;

    // trade-up contracts (revival addition): parsed collections, plus a lookup
    // from (itemDefIndex << 32 | paintKitDefIndex) to the owning collection index
    std::vector<Collection> m_collections;
    std::unordered_map<uint64_t, size_t> m_collectionByItem;

    // trade-up contracts (revival addition): maps a skin (itemDef << 32 |
    // paintKitDef) to the unusual (knife/glove) loot list of its case, for the
    // 5 Covert -> gold recipe. Built by walking the case loot lists.
    std::unordered_map<uint64_t, const LootList *> m_unusualPoolByItem;
};
